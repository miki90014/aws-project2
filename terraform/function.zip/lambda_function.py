import json
import time
import requests


def lambda_handler(event, context):
    print("Funkcja Lambda rozpoczęła działanie.")
    for record in event['Records']:
        try:
            message_body = record['body']
            token = record['messageAttributes']['Token']['StringValue']
            backend_url = record['messageAttributes']['URL']['StringValue']
        except Exception as ex:
            print("Error: {ex}")
            continue

        print(f"Otrzymano wiadomość: {message_body}") 
        
        time.sleep(5)
        
        print(f"Przetworzono wiadomość: {message_body}")
        
        if any(char.isdigit() for char in message_body):
                headers = {
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json"
                }
                payload = {
                    "messageToSent": message_body,
                    "usernameReciever": "admin"
                }
                try:
                    print(f"Wysylanie wiadomosci do admina... {backend_url}:5000/send_message")
                    response = requests.post(url=f'{backend_url}:5000/send_message', headers=headers, json=payload, timeout=3)
                except Exception as ex:
                     print(f"Error: {ex}")
    return {
        'statusCode': 200,
        'body': json.dumps('Przetwarzanie zakonczone!')
    }